import handler from '../handler.mjs';
export default (req, res) => handler(req, res, 'send');
